# ADS401 Group H Final Data Status

## Completed Dataset

- Participants: 30
- AI-guide group: 15
- No-AI comparison group: 15
- Student level: 17 undergraduates and 13 postgraduates
- Final outcome items: Q7-Q15, nine ratings on a 1-5 scale
- Data completeness: 30 unique IDs; 270 of 270 item ratings present
- Missing values: none
- Out-of-range values: none

## Questionnaire

- Live link: https://v.wjx.cn/vm/wnB4jG2.aspx
- Researcher dashboard: https://www.wjx.cn/report/397354359.aspx?sat=1
- Full question reference: `ADS401_GroupH_Questionnaire_Bilingual.md`

## Statistical Analysis

- Two-sided independent-samples Mann-Whitney U test for each Q7-Q15 item
- Holm correction across the nine exploratory comparisons
- Rank-biserial correlation for effect direction and magnitude
- No pre-specified primary endpoint could be verified
- No item reached raw or Holm-adjusted p < .05

## Live-Form Version Mismatch

The original live form later added a required Q16 matrix that was absent from
the final dataset. A clean replacement questionnaire now contains Q1-Q15 only,
matches the collected variables, and has 30 confirmed responses. No placeholder
or imputed Q16 scores are used.

## Interpretation Boundary

The dataset does not contain task success, completion time, SUS, observation
records, or objective learning outcomes. The report therefore does not reuse
the previous usability analysis.

The planned allocation was alternating by arrival, but the recorded group
sequence is not strictly alternating. The final report does not describe the
study as randomized or interpret the observed differences as causal effects.
