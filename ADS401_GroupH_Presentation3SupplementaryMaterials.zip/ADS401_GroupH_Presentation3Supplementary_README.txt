ADS401 Group H - Presentation 3 Supplementary Materials

Study: Museum AI Guide Post-Visit Experience

Contents:
- Clean anonymous questionnaire CSV
- One CSV with the complete Q7-Q15 result table
- SPSS syntax and native .spv output
- Processed .sav data file
- SPSS comparison chart
- Bilingual questionnaire reference
- Data codebook
- Analysis explanation
- Presentation 3 speaker notes

Important:
- The final data contain 30 students, 15 per group.
- Q7-Q15 are 1-5 post-visit experience ratings.
- The dataset does not contain task success, completion time, SUS, or observation data.
- No item is significant before or after Holm correction.
- The recorded allocation sequence was not strictly alternating, so the report
  does not claim randomization or causal effects.
