ADS401 Group H - Presentation 3 Supplementary Materials

Project: Usability Evaluation of the XJTLU Museum AI System

This ZIP contains:
- Presentation 3 speaker notes
- Live questionnaire blueprint
- Blank merged analysis template
- SPSS analysis syntax
- Data collection status
- Project audit and submission checklist

The survey is live, but participant data collection is not complete. No participant findings are
fabricated in these materials. After collection, export Wenjuanxing responses, merge them with the
observation sheet by anonymous Participant ID, run the SPSS syntax, and insert the actual results into
the Presentation 3 result slide and web report.
